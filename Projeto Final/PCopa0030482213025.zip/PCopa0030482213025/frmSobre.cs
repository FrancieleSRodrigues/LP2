﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCopa0030482213025
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();

            lblSobre.Text = "Projeto Copa 2022 \n\n\n" +
                "Este trabalho foi desenvolvido pelos alunos: " +
                "\n\n\nAdriana Akagui - R.A: 0030482213036; " +
                "\n\nAlisson Donizetti de Lima - R.A: 0030482213017; " +
                "\n\nFranciele dos Santos Rodrigues - R.A: 0030482213025; " +
                "\n\nNicollas Pires Furquim Schlemm - R.A: 0030482213033.";
        }

    }

    
}
