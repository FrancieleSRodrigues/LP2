﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnFaturamento = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNomesTamanho = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverter
            // 
            this.btnInverter.Location = new System.Drawing.Point(130, 163);
            this.btnInverter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(198, 91);
            this.btnInverter.TabIndex = 0;
            this.btnInverter.Text = "Ler 20 Numeros e Inverter";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnFaturamento
            // 
            this.btnFaturamento.Location = new System.Drawing.Point(484, 163);
            this.btnFaturamento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnFaturamento.Name = "btnFaturamento";
            this.btnFaturamento.Size = new System.Drawing.Size(184, 91);
            this.btnFaturamento.TabIndex = 1;
            this.btnFaturamento.Text = "Calcular Faturamento";
            this.btnFaturamento.UseVisualStyleBackColor = true;
            this.btnFaturamento.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(816, 163);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(192, 91);
            this.btnTotal.TabIndex = 2;
            this.btnTotal.Text = "Verificar Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Location = new System.Drawing.Point(130, 345);
            this.btnArrayList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(198, 94);
            this.btnArrayList.TabIndex = 3;
            this.btnArrayList.Text = "Array List";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(484, 345);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(184, 94);
            this.btnMedia.TabIndex = 4;
            this.btnMedia.Text = "Calcular Medias";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNomesTamanho
            // 
            this.btnNomesTamanho.Location = new System.Drawing.Point(816, 345);
            this.btnNomesTamanho.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnNomesTamanho.Name = "btnNomesTamanho";
            this.btnNomesTamanho.Size = new System.Drawing.Size(192, 94);
            this.btnNomesTamanho.TabIndex = 5;
            this.btnNomesTamanho.Text = "Verificar Nomes e Tamanhos";
            this.btnNomesTamanho.UseVisualStyleBackColor = true;
            this.btnNomesTamanho.Click += new System.EventHandler(this.btnNomesTamanho_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 631);
            this.Controls.Add(this.btnNomesTamanho);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.btnFaturamento);
            this.Controls.Add(this.btnInverter);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnFaturamento;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNomesTamanho;
    }
}

