﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[5]; //RA: 0030482213025
            int[] tamanho = new int[5]; //vetor para armazenar os tamanhos dos nomes
            string auxiliar;
            string nomeSemEspaco;

            for (var i = 0; i < 5; i++)
            {
                auxiliar = Interaction.InputBox("Digite o " + (i+1) + "º nome: ", "Entrada de Nomes");
                nomes[i] = auxiliar;

                nomeSemEspaco = auxiliar.Replace(" ", "");

                tamanho[i] = nomes[i].Length;
            }

            for(var i=0; i<5; i++)
            {
                lstbxNomes.Items.Add("Nome: " + nomes[i] + " tem " + tamanho[i] + " caracteres.");
            }
        }
    }
}
