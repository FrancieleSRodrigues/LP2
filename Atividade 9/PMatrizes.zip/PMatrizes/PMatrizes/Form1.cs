﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20]; //criação do vetor
            string auxiliar;

            for (var i=0; i<20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido");
                    i--;
                }
            }

            //para inverter os dados do vetor:

            auxiliar = "";
            Array.Reverse(vetor);

            foreach (int i in vetor)
                auxiliar += i + "\n";

            MessageBox.Show(auxiliar);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            double faturamento = 0; 
            string auxiliar = "";
            
            for(var i=0; i<10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria " + (i + 1), "Entrada das quantidades");

                if (!double.TryParse(auxiliar, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
                }
                else
                {
                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço da mercadoria " + (i + 1), "Entrada de preços");
                        if (!double.TryParse(auxiliar, out preco[i]))
                        {
                            MessageBox.Show("Preço Inválido!");
                        }
                        else
                        {
                            if (preco[i] <= 0)
                            {
                                MessageBox.Show("Preço deve ser maior que zero!");
                            }
                        }
                    }

                    faturamento += quantidade[i] * preco[i];
                }

            }
            MessageBox.Show("Faturamento: R$" + faturamento.ToString("N2"));

        }

        private void btnTotal_Click(object sender, EventArgs e) //Botão 3
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for(I=0; I<N-1; I++)
            {
                Total += Alunos[I].Length;
                MessageBox.Show("Total: " + Total);
            }
        }

        private void btnArrayList_Click(object sender, EventArgs e) //Botão 4
        {
            ArrayList lista = new ArrayList();
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Débora");
            lista.Add("Fátima");
            lista.Add("João");
            lista.Add("Janete");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otávio");

            foreach( string nome in lista)
            {
                MessageBox.Show(nome);
            }
        }

        private void btnMedia_Click(object sender, EventArgs e) //Botão 5
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            string auxiliar;

            for (var i = 0; i < 20; i++)
            { 
                media = 0;

                for( var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a " + (j+1) + "º nota do aluno " + (i+1) + " :", "Entrada de Notas");
                    
                    if (!double.TryParse(auxiliar, out notas[i,j]))
                    {
                        MessageBox.Show("Valor Inválido");
                        j--;
                    }
                    else if(notas[i,j] <= 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show("Valor Inválido");
                        j--;
                    }

                    media += notas[i, j];
                }
                
                media /= 3;

                MessageBox.Show("Aluno " + (i+1) + " : média: " + media.ToString("N1"));
            }
        }

        private void btnNomesTamanho_Click(object sender, EventArgs e) //Botão 6
        {
            frmExercicio6 FrmExercicio6 = new frmExercicio6(); //criou o objeto
            FrmExercicio6.Show(); //Mostra o formulario desejado.

        }
    }
}
