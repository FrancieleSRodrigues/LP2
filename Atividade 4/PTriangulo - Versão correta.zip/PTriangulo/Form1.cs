﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxA.Text = String.Empty;
            mskbxB.Text = String.Empty;
            mskbxC.Text = String.Empty;
            txtResultado.Text = String.Empty;

            mskbxA.Focus();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            Double A, B, C;
            if (Double.TryParse(mskbxA.Text, out A) &&
                   Double.TryParse(mskbxB.Text, out B) &&
                   Double.TryParse(mskbxC.Text, out C))
            {
                if (A < (B + C) && A > Math.Abs(B - C) &&
                    (B < (A + C) && B > Math.Abs(A - C)) &&
                    (C < (A + B) && C > Math.Abs(A - B)))
                {
                    if (A == B && B == C)
                    {
                        txtResultado.Text = "Triângulo Equilátero";
                        mskbxA.Focus();
                    }
                    else
                    {
                        if (A == B || B == C || C == A)
                        {
                            txtResultado.Text = "Triângulo Isóceles";
                            mskbxA.Focus();
                        }
                        else
                        {
                            txtResultado.Text = "Triângulo Escaleno";
                            mskbxA.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Não é um triângulo! Por favor, insira novos valores");
                    mskbxA.Focus();
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos. Tente novamente!");
                mskbxA.Focus();
            }

        }
    }
}
