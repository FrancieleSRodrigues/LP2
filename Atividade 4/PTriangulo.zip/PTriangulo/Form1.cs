namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Double A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxA.Text = String.Empty;
            mskbxB.Text = String.Empty;
            mskbxC.Text = String.Empty;
            txtResultado.Text = String.Empty;

            mskbxA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(mskbxA.Text, out A) &&
                   Double.TryParse(mskbxB.Text, out B) &&
                   Double.TryParse(mskbxC.Text, out C))
            {
                if (A < (B + C) && A > Math.Abs(B - C) &&
                    (B < (A + C) && B > Math.Abs(A - C)) &&
                    (C < (A + B) && C > Math.Abs(A - B)))
                {
                    if (A == B && B == C)
                    {
                        txtResultado.Text = "Tri�ngulo Equil�tero";
                        mskbxA.Focus();
                    }
                    else
                    {
                        if (A == B || B == C || C == A)
                        {
                            txtResultado.Text = "Tri�ngulo Is�celes";
                            mskbxA.Focus();
                        }
                        else
                        {
                            txtResultado.Text = "Tri�ngulo Escaleno";
                            mskbxA.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("N�o � um tri�ngulo! Por favor, insira novos valores");
                    mskbxA.Focus();
                }
            }
            else
            {
                MessageBox.Show("Valores inv�lidos. Tente novamente!");
                mskbxA.Focus();
            }
        }
    }
}