﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class frmCampeonato : Form
    {
        public frmCampeonato()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[,] gols = new int[5, 3];
            string golfeito;
            string golrecebido;
            string times = "";
          

            for (int i = 0; i < 5; i++ )
            {
             
                    golfeito = Interaction.InputBox("Time: " + (i + 1) + "\n\n" + " Gol feito: " );
                    
                    if (!int.TryParse(golfeito, out gols[i, 0]))
                    {
                        MessageBox.Show("Valor Inválido!");
                        
                    }
                    else
                    {
                        if (gols[i, 0] < 0)
                        {
                            MessageBox.Show("Valor deve ser maior que 0!");
                            
                        }
                    }
                 

                
            }
             for (int i = 0; i < 5; i++ )
             {
                    golrecebido = Interaction.InputBox("Time: " + (i + 1) + "\n\n" + " Gol recebido: ");

                    if (!int.TryParse(golrecebido, out gols[i, 1]))
                    {
                        MessageBox.Show("Valor Inválido!");
                      
                    }
                    else
                    {
                        if (gols[i, 1] < 0)
                        {
                            MessageBox.Show("Valor deve ser maior que 0!");
                          
                        }
                    }
                
               
            }
             

            for (int i = 0; i < 5; i++)
            {
                    gols[i, 2] = gols[i, 0] - gols[i, 1];
                                
                times = times + "Time " + (i + 1).ToString("00") + ": " + " saldo de gols: " + gols[i,2].ToString("N2") + "\n";
                i++;
            }

            MessageBox.Show("Times: \n\n" + times.ToString());


            }

            }
            
        }
    

