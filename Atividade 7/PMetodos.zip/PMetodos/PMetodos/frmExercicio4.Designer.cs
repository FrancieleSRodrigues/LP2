﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtfTexto = new System.Windows.Forms.RichTextBox();
            this.btnCaracterNumerico = new System.Windows.Forms.Button();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnCaracterAlfabetico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtfTexto
            // 
            this.rtfTexto.Location = new System.Drawing.Point(58, 61);
            this.rtfTexto.Name = "rtfTexto";
            this.rtfTexto.Size = new System.Drawing.Size(811, 209);
            this.rtfTexto.TabIndex = 0;
            this.rtfTexto.Text = "";
            // 
            // btnCaracterNumerico
            // 
            this.btnCaracterNumerico.Location = new System.Drawing.Point(58, 382);
            this.btnCaracterNumerico.Name = "btnCaracterNumerico";
            this.btnCaracterNumerico.Size = new System.Drawing.Size(237, 95);
            this.btnCaracterNumerico.TabIndex = 1;
            this.btnCaracterNumerico.Text = "Caracteres Numericos";
            this.btnCaracterNumerico.UseVisualStyleBackColor = true;
            this.btnCaracterNumerico.Click += new System.EventHandler(this.btnCaracterNumerico_Click);
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Location = new System.Drawing.Point(369, 382);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(246, 95);
            this.btnCaracterBranco.TabIndex = 2;
            this.btnCaracterBranco.Text = "Primeiro Caracter em Branco";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnCaracterAlfabetico
            // 
            this.btnCaracterAlfabetico.Location = new System.Drawing.Point(693, 382);
            this.btnCaracterAlfabetico.Name = "btnCaracterAlfabetico";
            this.btnCaracterAlfabetico.Size = new System.Drawing.Size(189, 95);
            this.btnCaracterAlfabetico.TabIndex = 3;
            this.btnCaracterAlfabetico.Text = "Caracteres Alfabéticos";
            this.btnCaracterAlfabetico.UseVisualStyleBackColor = true;
            this.btnCaracterAlfabetico.Click += new System.EventHandler(this.btnCaracterAlfabetico_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 592);
            this.Controls.Add(this.btnCaracterAlfabetico);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnCaracterNumerico);
            this.Controls.Add(this.rtfTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtfTexto;
        private System.Windows.Forms.Button btnCaracterNumerico;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnCaracterAlfabetico;
    }
}