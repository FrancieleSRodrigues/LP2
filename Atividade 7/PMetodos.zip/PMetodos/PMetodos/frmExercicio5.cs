﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("1° Número inválido, tente novamente");
                txtNumero1.Text = String.Empty;
            }
            else if (!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("2° Número inválido, tente novamente");
                txtNumero2.Text = String.Empty;
            }
                else if (numero1 > numero2)
                {
                    MessageBox.Show("Primeiro número é maior que o segundo. Insira novamente os dados:");
                    txtNumero1.Text = String.Empty;
                    txtNumero2.Text = String.Empty;
                }
                else
                {
                    Random random = new Random();

                    double r = random.Next(numero1, numero2);

                    MessageBox.Show("Numero sorteado: " + r);
            }

        }
    }
}
