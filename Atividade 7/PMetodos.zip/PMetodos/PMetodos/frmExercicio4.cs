﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracterNumerico_Click(object sender, EventArgs e)
        {
            string texto = rtfTexto.Text;

            int qtdeCaracterNumerico = 0;

            for(var i = 0; i<texto.Length; i++)
            {
                if (Char.IsNumber(texto[i]))
                {
                    qtdeCaracterNumerico += 1;
                }
            }
            MessageBox.Show("Caracteres Numéricos: " + qtdeCaracterNumerico);
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            string texto = rtfTexto.Text;
            int i = 0;

            while (i < texto.Length)
            {
                if (Char.IsWhiteSpace(texto[i]))
                {
                    MessageBox.Show("Primeiro Caracter Branco na posição: " + i);
                    break;
                }
                else
                    i++;
            }
        }

        private void btnCaracterAlfabetico_Click(object sender, EventArgs e)
        {
            string texto = rtfTexto.Text;

            int qtdeCaracterAlfabetico = 0;

            foreach (char i in texto)
            {
                if (Char.IsLetter(i))
                {
                    qtdeCaracterAlfabetico += 1;
                }
            }
            MessageBox.Show("Caracteres Alfabéticos: " + qtdeCaracterAlfabetico);
        }
    }
}
