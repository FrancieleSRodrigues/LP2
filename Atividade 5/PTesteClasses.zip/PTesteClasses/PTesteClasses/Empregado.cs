﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTesteClasses
{
    abstract class Empregado
    // classe é abstrata: não pode ter objetos a partir dela
    {
        // criação dos atributos
        // private é para esconder os atributos

        private int matricula; // atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        //criação das propriedades referentes aos atributos
        //propriedades são public para todo mundo enxergar

        public int Matricula //propriedade
        {
            get{return matricula;}
            set{matricula = value;}
        }

        public string NomeEmpregado
        {
            get{return nomeEmpregado;}
            set{nomeEmpregado = value;}
        }

        public DateTime DataEntradaEmpresa
        {
            get{return dataEntradaEmpresa;}
            set{dataEntradaEmpresa = value;}
        }

        public char HomeOffice
        {
            get {return homeOffice;}
            set {homeOffice = value;}
        }

        
        // Dentro das classes, os métodos são as funções:

        public String VerificaHome() // método
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado NÃO trabalha em home office";
        }

        public virtual int TempoTrabalho()
        {
            // representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            //retornará a data em dias (inteiro)
            return (span.Days);
        }

        public abstract double SalarioBruto(); // não preciso implementar
        // toda classe que tem o abstract se torna abstrata
        // o código sera obrigada quando criar a "classe filha"
        // o salário bruto do horista é diferente do mensalista - código será diferente.
        // se há um método abstrato, toda a classe se torna abstrata.

    }
}
