﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    class Mensalista : Empregado // especialização -> herança
    {
        public double SalarioMensal { get; set; }
        // criando a propriedade assim já entende-se que há um atributo oculto.
        // ponto negativo: desse jeito não há como se implementar a lógica.

        //sobreescrevendo o método
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        //construtor --> new
        // 3 versões do método new: Será utilizada a que estiver com os parâmetros correspondentes
        public Mensalista()
        {
            MessageBox.Show("Passei por aqui");
        }

        public Mensalista(double x)
        {

        }

        public Mensalista(int matx, string nomex, DateTime datax, double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;
        }
    }
}
