﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = String.Empty;
            mskbxAltura.Text = String.Empty;
            txtIMC.Text = String.Empty;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Peso, Altura, IMC;

            if (double.TryParse(mskbxPeso.Text, out Peso) && double.TryParse(mskbxAltura.Text, out Altura))
            {
                if (Altura <= 0)
                    MessageBox.Show("Dado inválido!");

                else
                {
                    IMC = Peso / Math.Pow(Altura, 2);
                    IMC = Math.Round(IMC, 1);
                    txtIMC.Text = IMC.ToString();

                    if (IMC < 18.5)
                        MessageBox.Show("Magreza - Grau de obesidade 0");
                    else
                        if (IMC <= 24.9)
                            MessageBox.Show("Normal - Grau de obesidade 0");
                        else
                            if (IMC <= 29.9)
                                MessageBox.Show("Sobrepeso - Grau de obesidade I");
                            else
                                if (IMC <= 39.9)
                                    MessageBox.Show("Obesidade - Grau de obesidade II");
                                else
                                    MessageBox.Show("Obesidade Grave - Grau de obesidade III ");

                }
            }
            else
            {
                MessageBox.Show("Dados inválidos. Tente novamente!");
                mskbxPeso.Focus();
            }
        }

    }
}
