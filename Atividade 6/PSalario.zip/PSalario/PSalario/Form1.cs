﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double SalarioBruto;
            double SalarioFamilia;
            double SalarioLiquido;
            double DescontoINSS;
            double DescontoIRPF;

            lblDados.Text = ckbxCasado.Checked == false? "Os descontos do " +
                "salario do Sr(a). " + txtNome.Text + " que é solteiro (a) e que tem " +
               NuDFilhos.Value + " filho(s)" : "Os descontos do " +
                "salario do Sr(a). " + txtNome.Text + " que é casado (a) e que tem " +
                NuDFilhos.Value + " filho(s)";


            if (txtNome.Text == String.Empty)
            {
                MessageBox.Show("Insira seu nome");
                txtNome.Focus();
            }
            else
            {
                if (double.TryParse(mskbxSalarioBruto.Text, out SalarioBruto))
                {
                    if (SalarioBruto <= 0)
                    {
                        MessageBox.Show("Salário deve ser maior que 0");
                    }
                }
                else
                {
                    MessageBox.Show("Salario invalido");
                }

                //Calculo INSS
                if (SalarioBruto <= 800.47)
                {
                    mskbxINSS.Text = "7.65%";
                    DescontoINSS = SalarioBruto * 0.765;
                }
                else if (SalarioBruto <= 1050.00)
                {
                    mskbxINSS.Text = "8.65%";
                    DescontoINSS = SalarioBruto * 0.865;

                }
                else if (SalarioBruto <= 1400.77)
                {
                    mskbxINSS.Text = "9.00%";
                    DescontoINSS = SalarioBruto * 0.900;
                }
                else if (SalarioBruto <= 2801.56)
                {
                    mskbxINSS.Text = "11.00%";
                    DescontoINSS = SalarioBruto * 0.110; ;
                }
                else
                {
                    mskbxINSS.Text = "Teto";
                    DescontoINSS = 308.17;
                }

                //Calculo IRPF
                if (SalarioBruto <= 1257.12)
                {
                    mskbxIRPF.Text = "Isento";
                    DescontoIRPF = 0;
                }
                else if (SalarioBruto <= 2512.08)
                {
                    mskbxIRPF.Text = "15.00%";
                    DescontoIRPF = SalarioBruto * 0.150;
                }
                else
                {
                    mskbxIRPF.Text = "27.5%";
                    DescontoIRPF = SalarioBruto * 0.275;
                }

                //Salario Familia
                if (SalarioBruto <= 435.52)
                {
                    SalarioFamilia = Convert.ToDouble(NuDFilhos.Value) * 22.33;
                }
                else if (SalarioBruto <= 654.61)
                {
                    SalarioFamilia = Convert.ToDouble(NuDFilhos.Value) * 15.74;
                }
                else
                {
                    SalarioFamilia = Convert.ToDouble(NuDFilhos.Value) * 0;
                }

                mskbxSalarioFamilia.Text = SalarioFamilia.ToString("N2");
                mskbxDescontoINSS.Text = DescontoINSS.ToString("N2");
                mskbxDescontoIRPF.Text = DescontoIRPF.ToString("N2");

                SalarioLiquido = SalarioBruto - DescontoINSS - DescontoIRPF + SalarioFamilia;
                mskbxSalarioLiquido.Text = SalarioLiquido.ToString("N2");
            }
        }
    }
}
